# Git for Teams of One or More 

Emma Jane Westby 

Twitter: [emmajanehw](http://twitter.com/emmajanehw)

[emma.westby@drupalize.me](mailto:emma.westby@drupalize.me)

repo: https://github.com/DrupalizeMe/workflow-git-workshop

-----
## Hello! My Name is [Emma](http://en.wikipedia.org/wiki/Emma_Jane_Hogbin)

<!-- .slide: data-background-image="assets/beesuit.jpg" -->
<!-- .slide: data-background-position="top left" -->
<!-- .slide: data-state="bgimage" -->

<a href="http://drupalize.me"><img class="fragment" style="background-color: white; padding: .5em; border: none" src="../lib/themes/drupalize.me/images/drupalizeme-logo.png" class="no-border" width="35%" class="left" style="padding-top: 10px;" alt="Drupalize.Me logo"/></a>

Note: I have been using version control for 10+ years and had
the great misfortune of teaching CVS to arts majors before
distributed version control was a thing.
