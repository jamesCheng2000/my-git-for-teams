# Thanks!

Feedback Welcome!

https://joind.in/10819

[@emmajanehw](http://twitter.com/emmajanehw) // [@drupalizeme](http://twitter.com/drupalizeme)

https://github.com/DrupalizeMe/workflow-git-workshop
