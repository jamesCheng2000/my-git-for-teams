# Teaching Git for Teams of One or More 

This directory contains a set of files which can be easily converted into a one-hour session, half day workshop, or full day workshop on the git workflow.

1. Create a copy of the file TEMPLATE.html.
2. Add slides from the relevant markdown files in the slides directory.
3. Update the intro (00-instructor-intro.md) and outro files (00-exit-evals.md) with the relevant details for your presentation.
